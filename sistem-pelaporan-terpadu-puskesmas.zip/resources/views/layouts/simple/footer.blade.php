 <!-- footer start-->
 <footer class="footer">
     <div class="container-fluid">
         <div class="row">
             <div class="col-md-12 footer-copyright text-center">
                {{-- <div class="copyright text-center text-sm text-muted text-lg-start"> --}}
                    ©
                    <script>
                        document.write(new Date().getFullYear())
                    </script>,
                    made with <i class="fa fa-heart"></i> by
                    <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Dignity Digital
                        Space</a>

                {{-- </div> --}}
             </div>
         </div>
     </div>
 </footer>

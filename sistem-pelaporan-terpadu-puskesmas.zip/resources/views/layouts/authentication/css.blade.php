
@vite(['public/assets/scss/app.scss'])

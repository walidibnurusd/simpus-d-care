<!-- Modal Add Action -->
<div class="modal fade" style="z-index: 1050;" id="addActionModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                @if ($routeName === 'action.dokter.index')
                    <h5 class="modal-title" id="exampleModalLabel">TINDAKAN POLI UMUM</h5>
                @elseif($routeName === 'action.dokter.gigi.index')
                    <h5 class="modal-title" id="exampleModalLabel">TINDAKAN POLI GIGI</h5>
                @else
                    <h5 class="modal-title" id="exampleModalLabel">TINDAKAN UGD</h5>
                @endif
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addPatientForm" action="" method="POST" class="px-3">
                    @csrf
                    @if ($routeName === 'action.dokter.index')
                        <input type="hidden" name="tipe" id="tipe" value="poli-umum">
                    @elseif($routeName === 'action.dokter.gigi.index')
                        <input type="hidden" name="tipe" id="tipe" value="poli-gigi">
                    @else
                        <input type="hidden" name="tipe" id="tipe" value="ruang-tindakan">
                    @endif
                    <div class="row">
                        <div class="col-4">
                            <h5>Detail Pasien</h5>
                            <div id="patientDetails"
                                style="display:none; margin-top: 10px; padding: 10px; border-radius: 5px;">
                                <p><strong>N I K</strong> : <span id="displayNIK"></span></p>
                                <p><strong>Nama Pasien</strong> : <span id="displayName"></span></p>
                                {{-- <p><strong>J.Kelamin</strong> : <span id="displayGender"></span></p> --}}
                                <p><strong>Umur</strong> : <span id="displayAge"></span></p>
                                <p><strong>Telepon/WA</strong> : <span id="displayPhone"></span></p>
                                <p><strong>Alamat</strong> : <span id="displayAddress"></span></p>
                                <p><strong>Darah</strong> : <span id="displayBlood"></span></p>
                                {{-- <p><strong>Pendidikan</strong> : <span id="displayEducation"></span></p> --}}
                                {{-- <p><strong>Pekerjaan</strong> : <span id="displayJob"></span></p> --}}
                                <p><strong>Nomor RM</strong> : <span id="displayRmNumber"></span></p>
                            </div>
                        </div>
                        <div class="row col-8">
                            <div class="col-12">
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="nik">Cari Pasien</label>
                                            <div class="input-group">
                                                <input type="text" hidden id="idAction" name="idAction"
                                                    value="">
                                                <input readonly type="text" class="form-control" id="nik"
                                                    name="nik" placeholder="NIK" required>
                                                <div class="input-group-append">
                                                    <button class="btn btn-primary" type="button" id="btnCariNIK"
                                                        data-bs-toggle="modal" data-bs-target="#modalPasien">
                                                        Cari
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="tanggal">Tanggal</label>
                                            <input type="date" class="form-control" id="tanggal" name="tanggal"
                                                placeholder="Pilih Tanggal" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="doctor">Dokter</label>
                                            <select class="form-control" id="doctor" name="doctor" required>
                                                <option value="" disabled selected>Pilih Dokter</option>
                                                @foreach ($dokter as $item)
                                                    <option value="{{ $item['name'] }}">{{ $item['name'] }}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="kunjungan">Kunjungan</label>
                                            <select class="form-control" id="kunjungan" name="kunjungan" required>
                                                <option value="" disabled selected>Pilih Jenis Kunjungan</option>
                                                <option value="baru">Baru </option>
                                                <option value="lama">Lama </option>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="row g-2">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="jenis_kartu">Jenis Kartu</label>
                                            <input type="text" class="form-control" id="jenis_kartu"
                                                name="jenis_kartu" readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="nomor_kartu">Nomor Kartu</label>
                                            <input type="text" class="form-control" id="nomor_kartu"
                                                name="nomor_kartu" placeholder="Masukkan Nomor" readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="wilayah_faskes">Wilayah Faskes</label>
                                            <select class="form-control" id="wilayah_faskes" name="faskes" required>
                                                <option value="" disabled selected>Pilih Wilayah Faskes</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>

                                            </select>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div style="display: flex; align-items: center; text-align: center;">
                                <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                                <span style="margin: 0 10px; white-space: nowrap;">Pemeriksaan</span>
                                <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                            </div>

                            <div class="col-12">
                                <div class="row g-2">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="sistol">Sistol</label>
                                            <input type="text" class="form-control" id="sistol" name="sistol"
                                                placeholder="Masukkan Sistol" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="diastol">Diastol</label>
                                            <input type="text" class="form-control" id="diastol" name="diastol"
                                                placeholder="Masukkan Diastol" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="berat_badan">Berat Badan</label>
                                            <input type="text" class="form-control" id="berat_badan"
                                                name="beratBadan" placeholder="Masukkan Berat Badan" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="tinggi_badan">Tinggi Badan</label>
                                            <input type="text" class="form-control" id="tinggi_badan"
                                                name="tinggiBadan" placeholder="Masukkan Tinggi Badan" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="ling_pinggang">Ling. Pinggang</label>
                                            <input type="text" class="form-control" id="ling_pinggang"
                                                name="lingkarPinggang" placeholder="Masukkan Ling. Pinggang" required>
                                        </div>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="nadi">Nadi</label>
                                            <input type="text" class="form-control" id="nadi" name="nadi"
                                                placeholder="Masukkan Nadi" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="nafas">Pernafasan</label>
                                            <input type="text" class="form-control" id="nafas" name="nafas"
                                                placeholder="Masukkan Nafas" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="suhu">Suhu</label>
                                            <input type="text" class="form-control" id="suhu" name="suhu"
                                                placeholder="Masukkan Suhu" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if ($routeName === 'action.dokter.index')
                                <div style="display: flex; align-items: center; text-align: center;">
                                    <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                                    <span style="margin: 0 10px; white-space: nowrap;">Pemeriksaan Fisik</span>
                                    <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                                </div>
                                <div class="container">
                                    <div class="row g-2">
                                        <div class="col-md-2 ">
                                            <label for="mata_anemia" style="color: green;">Mata-Anemia</label>
                                            <select class="form-control" id="mata_anemia" name="mata_anemia">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="pupil" style="color: green;">Mata-Pupil</label>
                                            <select class="form-control" id="pupil" name="pupil">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="isokor">Isokor</option>
                                                <option value="anisokor">Anisokor</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="ikterus" style="color: green;">Mata-Ikterus</label>
                                            <select class="form-control" id="ikterus" name="ikterus">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="udem_palpebral" style="color: green;">Mata-Udem
                                                Palpebral</label>
                                            <select class="form-control" id="udem_palpebral" name="udem_palpebral">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="nyeri_tekan" style="color: green;">Abdomen-Nyeri Tekan</label>
                                            <select class="form-control" id="nyeri_tekan" name="nyeri_tekan">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="peristaltik" style="color: green;">Abdomen-Peristaltik</label>
                                            <select class="form-control" id="peristaltik" name="peristaltik">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="normal">Normal</option>
                                                <option value="meningkat">Meningkat</option>
                                                <option value="menurun">Menurun</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="ascites" style="color: green;">Abdomen-Ascites</label>
                                            <select class="form-control" id="ascites" name="ascites">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="lokasi_abdomen" style="color: green;">Abdomen-Lokasi</label>
                                            <input type="text" class="form-control" id="lokasi_abdomen"
                                                name="lokasi_abdomen" placeholder="Lokasi Abdomen">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="thorax" style="color: green;">Thorax</label>
                                            <select class="form-control" id="thorax" name="thorax">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="simetris">Simetris</option>
                                                <option value="asimetris">Asimetris</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="thorax_bj" style="color: green;">Thorax-BJ I/II</label>
                                            <select class="form-control" id="thorax_bj" name="thorax_bj">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="regular">Regular</option>
                                                <option value="irregular">Irregular</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="suara_nafas" style="color: green;">Thorax-Suara Nafas</label>
                                            <select class="form-control" id="suara_nafas" name="suara_nafas">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="vesikuler">Vesikuler</option>
                                                <option value="bronkoveskuler">Bronkoveskuler</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="ronchi" style="color: green;">Thorax-Ronchi</label>
                                            <select class="form-control" id="ronchi" name="ronchi">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="wheezing" style="color: green;">Thorax-Wheezing</label>
                                            <select class="form-control" id="wheezing" name="wheezing">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="ekstremitas" style="color: green;">Ekstremitas</label>
                                            <select class="form-control" id="ekstremitas" name="ekstremitas">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="hangat">Hangat</option>
                                                <option value="dingin">Dingin</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="edema" style="color: green;">Ekstremitas-Edema</label>
                                            <select class="form-control" id="edema" name="edema">
                                                <option value="" disabled selected>pilih</option>
                                                <option value="ya">Ya</option>
                                                <option value="tidak">Tidak</option>
                                                <option value="lainnya">Lainnya</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="tonsil" style="color: green;">THT-Tonsil</label>
                                            <input type="text" class="form-control" id="tonsil" name="tonsil"
                                                placeholder="Tonsil">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="fharing" style="color: green;">THT-Fharing</label>
                                            <input type="text" class="form-control" id="fharing" name="fharing"
                                                placeholder="Fharing">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="kelenjar" style="color: green;">Leher-Pembesaran
                                                Kelenjar</label>
                                            <input type="text" class="form-control" id="kelenjar"
                                                name="kelenjar" placeholder="Pembesaran Kelenjar">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="genetalia" style="color: green;">Genetalia</label>
                                            <input type="text" class="form-control" id="genetalia"
                                                name="genetalia" placeholder="Genetalia Jika Diperlukan">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="warna_kulit" style="color: green;">Kulit-Warna</label>
                                            <input type="text" class="form-control" id="warna_kulit"
                                                name="warna_kulit" placeholder="Warna Kulit">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="turgor" style="color: green;">Kulit-Turgor</label>
                                            <input type="text" class="form-control" id="turgor" name="turgor"
                                                placeholder="Turgor Kulit">
                                        </div>
                                        <div class="col-md-2 ">
                                            <label for="neurologis" style="color: green;">Pemeriksaan
                                                Neurologis</label>
                                            <input type="text" class="form-control" id="neurologis"
                                                name="neurologis"
                                                placeholder="Pemeriksaan Neurologis Jika Diperlukan">
                                        </div>
                                    </div>
                                </div>
                                <div style="display: flex; align-items: center; text-align: center;">
                                    <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                                    <span style="margin: 0 10px; white-space: nowrap;">Pemeriksaan Penunjang</span>
                                    <hr style="flex: 1; border: none; border-top: 1px solid #ccc;">
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <label for="alkohol" style="color: rgb(19, 11, 241);">DIAGNOSA</label>
                            <select class="form-control" id="diagnosa" name="diagnosa[]" multiple>
                                @foreach ($diagnosa as $item)
                                    <option value="{{ $item->id }}">{{ $item->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="skrining" class="form-label">Hasil Skrining</label>
                                <button class="btn btn-primary w-100 mt-2" type="button" id="btnCariskrining"
                                    data-bs-toggle="modal" data-bs-target="#modalSkrining">
                                    Hasil Skrining
                                </button>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <label for="pemeriksaan_penunjang" style="color: rgb(19, 11, 241);">Pemeriksaan
                                Penunjang</label>
                            <textarea class="form-control" id="pemeriksaan_penunjang" name="pemeriksaan_penunjang"
                                placeholder="Pemeriksaan Penunjang"></textarea>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <label for="alkohol" style="color: rgb(19, 11, 241);">TINDAKAN</label>
                            <select class="form-control" id="tindakan" name="tindakan">
                                <option value="" disabled selected>pilih</option>
                                @if ($routeName === 'action.dokter.index')
                                    <option value="Diberikan Obat">Diberikan Obat</option>
                                    <option value="Dirujuk">Dirujuk</option>
                                @elseif($routeName === 'action.dokter.gigi.index')
                                    <option value="Gigi Sulung Tumpatan Sementara">Gigi Sulung Tumpatan Sementara
                                    </option>
                                    <option value="Gigi Tetap Tumpatan Sementara">Gigi Tetap Tumpatan Sementara
                                    </option>
                                    <option value="Gigi Tetap Tumpatan Tetap">Gigi Tetap Tumpatan Tetap
                                    </option>
                                    <option value="Gigi Sulung Tumpatan Tetap">Gigi Sulung Tumpatan Tetap
                                    </option>
                                    <option value="Perawatan Saluran Akar">Perawatan Saluran Akar
                                    </option>
                                    <option value="Gigi Sulung Pencabutan">Gigi Sulung Pencabutan
                                    </option>
                                    <option value="Gigi Tetap Pencabutan">Gigi Tetap Pencabutan
                                    </option>
                                    <option value="Pembersihan Karang Gigi">Pembersihan Karang Gigi
                                    </option>
                                    <option value="Odontectomy">Odontectomy
                                    </option>
                                    <option value="Sebagian Prothesa">Sebagian Prothesa
                                    </option>
                                    <option value="Penuh Prothesa">Penuh Prothesa
                                    </option>
                                    <option value="Reparasi Prothesa">Reparasi Prothesa
                                    </option>
                                    <option value="Premedikasi/Pengobatan">Premedikasi/Pengobatan
                                    </option>
                                    </option>
                                    <option value="Tindakan Lain">Tindakan Lain
                                    </option>
                                    <option value="Incici Abses Gigi">Incici Abses Gigi</option>
                                @else
                                    <option value="Observasi Tanpa Tindakan Invasif">Observasi Tanpa Tindakan Invasif
                                    </option>
                                    <option value="Observasi Dengan Tindakan Invasif">Observasi Dengan Tindakan Invasif
                                    </option>
                                    <option value="Tidak Ada">Tidak Ada
                                    </option>
                                    <option value="Corpus Alineum">Corpus Alineum
                                    </option>
                                    <option value="Ekstraksi Kuku">Ekstraksi Kuku
                                    </option>
                                    <option value="Sircumsisi (Bedah Ringan)">Sircumsisi (Bedah Ringan)
                                    </option>
                                    <option value="Incisi Abses">Incisi Abses
                                    </option>
                                    <option value="Rawat Luka">Rawat Luka
                                    </option>
                                    <option value="Ganti Verban">Ganti Verban
                                    </option>
                                    <option value="Spooling">Spooling
                                    </option>
                                    <option value="Toilet Telinga">Toilet Telinga
                                    </option>
                                    <option value="Tetes Telinga">Tetes Telinga
                                    </option>
                                    <option value="Aff Hecting">Aff Hecting
                                    </option>
                                    </option>
                                    <option value="Hecting (Jahit Luka)">Hecting (Jahit Luka)
                                    </option>
                                    <option value="Tampon/Off Tampon">Tampon/Off Tampon</option>
                                @endif
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="obat" style="color: rgb(19, 11, 241);">Obat</label>
                            <textarea class="form-control" id="obat" name="obat" placeholder="Obat"></textarea>
                        </div>
                        <div class="col-md-4">
                            <label for="alkohol" style="color: rgb(19, 11, 241);">RUJUK RS</label>
                            <select class="form-control" id="rujuk_rs" name="rujuk_rs">
                                <option value="" disabled selected>pilih</option>
                                @foreach ($rs as $item)
                                    <option value="{{ $item->id }}">{{ $item->name }}</option>
                                @endforeach

                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="alkohol" style="color: rgb(19, 11, 241);">KETERANGAN</label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan"
                                placeholder="Keterangan" required>
                        </div>


                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary">Simpan Data</button>
                </form>
            </div>
        </div>
    </div>

</div>


@include('component.modal-table-pasien-dokter')
@include('component.modal-skrining')


<script>
    $(document).ready(function() {
        $('#riwayat_penyakit_keluarga').select2({
            placeholder: "Pilih",
            allowClear: true,
            minimumResultsForSearch: 0
        });
    });
    $(document).ready(function() {
        $('#riwayat_penyakit_tidak_menular').select2({
            placeholder: "Pilih",
            allowClear: true,
            minimumResultsForSearch: 0
        });
    });
    $(document).ready(function() {
        $('#diagnosa').select2({
            placeholder: "Pilih",
            allowClear: true,
            minimumResultsForSearch: 0
        });
    });
    $(document).ready(function() {
        $('#tindakan').select2({
            placeholder: "Pilih",
            allowClear: true,
            minimumResultsForSearch: 0
        });
    });
</script>
<style>
    .select2-dropdown {
        z-index: 9999 !important;
    }
</style>
<script>
    $(document).ready(function() {
        // Set z-index for modalPasien to be higher than addActionModal
        // $('#modalPasien').on('show.bs.modal', function() {
        //     $(this).css('z-index', '2000'); // set a high z-index for modalPasien
        // });

        // // Remove backdrop when modalPasien is closed
        // $('#modalPasien').on('hidden.bs.modal', function() {
        //     $('.modal-backdrop').not('.modal-stack').remove();
        // });
    });
</script>



<script>
    document.addEventListener('DOMContentLoaded', function() {

        // Display success message if session has a success
        @if (session('success'))
            Swal.fire({
                title: 'Success!',
                text: "{{ session('success') }}",
                icon: 'success',
                confirmButtonText: 'OK'
            });
        @endif

        // Display error message if validation errors exist
        @if ($errors->any())
            Swal.fire({
                title: 'Error!',
                html: '<ul>' +
                    '@foreach ($errors->all() as $error)' +
                    '<li>{{ $error }}</li>' +
                    '@endforeach' +
                    '</ul>',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        @endif
    });
</script>
